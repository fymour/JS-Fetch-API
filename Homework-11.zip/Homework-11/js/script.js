const base_url = 'https://www.breakingbadapi.com/api'
const containerLive = document.getElementById('container-live');
// const imgUrl = ""

const render = (data) => {
    const lastc = data.map((item, index) => {
        let result = ''
        let resField = ''
        result += `
        <tr>
        <td>${item.name}</td>
        <td>${item.nickname}</td>
        <td>${item.occupation}</td>
        <td>${item.portrayed}</td>
        <td>${item.status}</td>
        <td><img src="${item.img}" width="100px"></img></td> 
        </tr>`
        return result
    })
    containerLive.innerHTML = lastc.join('')
    console.log(data);
}

const renderBad = (data) => {
    const fields = ['name', 'occupation', 'imgUrl']
    render(data, fields, containerLive);
}
const fetcher = (url, renderfunction) => {
    fetch(`${base_url}/characters`)
        .then(response => response.json())
        .then(data => renderfunction(data))
}
const fetchBase = () => {
    const url = `${base_url}/characters`
    fetcher(url, render)
}
fetchBase()

function reset(){
    window.location.reload()
}   